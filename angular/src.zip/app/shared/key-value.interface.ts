export interface IKeyValue {
    key: string;
    value: string;
}
